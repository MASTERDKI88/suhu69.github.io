<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>SUHU69 Agen Betting Online Terbesar Terpercaya - Menang Berapapun Pasti DIBAYAR !</title>
    <meta name="description" content="SUHU69 Situs Judi online yang menyediakan game Togel online,togel sgp,togel singapore,togel hk,togel hongkong,slot game,pragmatic,idn live paling aman dan terpercaya." />
<meta name="keywords" content="SUHU69, slot online, togel online,pragmatic,jdb, slot deposit pulsa, judi slot online,togel hk,togel hongkong,togel sgp,togel singapore" />
<meta name="google-site-verification" content="A0TocdhVzHwzH_yTCSr0PrBJhSNisPGgpSRGuaUVO1c" />
<link rel="canonical" href="https://suhu69bet.com/" />
<link rel="shortcut icon" href="https://i.ibb.co/LpJm3KX/suhu.png">    <meta name="theme-color" content="#1b1b1b">
        <meta name="viewport" content="width=1200, initial-scale=0.33">
        <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Abel|Oswald:400|PT+Sans:400,700|Open+Sans:300,400,700,800" rel="stylesheet">
    <link href="css/webduo.css" rel="stylesheet" type="text/css" />
    <link href="css/mediaduo.css" rel="stylesheet" type="text/css" />
    <link rel="icon" type="image/png" href="favicon.png">
    
    <style>
		#picleft{
			background:url(https://img.pay4d.info/picleft.jpg) no-repeat;
			background-size: 331px;
			transition: 2s;
		}
			
		#picleft:hover{
			background:url(https://img.pay4d.info/picleft-b.jpg) no-repeat;
			background-size: 331px;
			transition: 0.3s;
		}
			
		#picmid{
			background:url(https://img.pay4d.info/picmid.jpg) no-repeat;
			background-size: 331px;
			transition: 2s;
		}
			
		#picmid:hover{
			background:url(https://img.pay4d.info/picmid-b.jpg) no-repeat;
			background-size: 331px;
			transition: 0.3s;
		}
			
		#picright{
			background:url(https://img.pay4d.info/picrightsport.jpg) no-repeat;
			background-size: 331px;
			transition: 2s;
		}
			
		#picright:hover{
			background:url(https://img.pay4d.info/picrightsport-b.jpg) no-repeat;
			background-size: 331px;
			transition: 0.3s;
		}

	</style>
    
</head>
<body>
<div id="mobile" style="font-weight: 400">
<div class="shadow broadcast-marquee marqueemobile" style="height: 28px; padding: 4px 5px 2px 5px;white-space:nowrap; overflow: hidden"><div class="abel" id="broadcast" style="white-space:nowrap;width: 1200px"></div></div>
    
    <div class="logo-div" style="text-align:center">
        <div style="margin-top:10px"><img src="images/logo.png" id="logo-img"/></div>
  </div>
    
  	    <div class="menubg shadow" style="width:20%;" onclick="location.href='#togel'"><img src="https://img.pay4d.info/mobile-togel.png" style="height: 75px; margin-top: -5px"></div>
    	    <div class="menubg shadow" style="width:20%;;" onclick="toggleslot();"><img src="https://img.pay4d.info/mobile-slot.png" style="height: 75px; margin-top: -5px"></a></div>
    <div class="menubg shadow" style="width:20%;;" onclick="togglelive();"><img src="https://img.pay4d.info/mobile-casino.png" style="height: 75px; margin-top: -5px"></div>
    <div class="menubg shadow" style="width:20%;;" onclick="togglesport();"><img src="https://img.pay4d.info/mobile-sport.png" style="height: 75px; margin-top: -5px"></div>
    <div class="menubg shadow" style="width:20%;;" onclick="toggletembak();"><img src="https://img.pay4d.info/mobile-tembakikan.png" style="height: 75px; margin-top: -5px"></div>   
    <div style="clear:both"></div>  
    <div class="header text-center shadow" id="header-line" style="width: 100%; margin-top:1px;"></div>
  

      
      
<!-- Live Menu -->
       <div style="margin-top: 1px;margin-bottom: 30px; padding:0px; text-align:center" id="livemenu">
         <div>
            <img class="mySlides-live" src="https://img.pay4d.info/picleft.jpg" width="100%" alt="">
            <img class="mySlides-live" src="https://img.pay4d.info/picleft-b.jpg" width="100%" alt="">
         </div>
         <div class="piclmd-div">
             <div class="abel piclmd-title">LIVE CASINO</div>
             <div class="abel piclmd-info">Permainan-permainan menarik secara Live.</div>
         </div>
         <div>
          <img src="images/bgline3.png" width="100%" height="6">
         </div>
       </div>
<!-- Live Menu End-->
        
<!-- Slot Menu -->
      <div style="margin-top:1px;margin-bottom: 30px; padding:0px; text-align:center" id="slotmenu">
         <div>
            <img class="mySlides-slot" src="https://img.pay4d.info/picmid.jpg" width="100%" alt="">
            <img class="mySlides-slot" src="https://img.pay4d.info/picmid-b.jpg" width="100%" alt="">
         </div>
         <div class="piclmd-div">
             <div class="abel piclmd-title">SLOT</div>
             <div class="abel piclmd-info">Ratusan Jenis Permainan dan Casino Game.</div>
         </div>
         <div>
          <img src="images/bgline3.png" width="100%" height="6">
         </div>
       </div>
<!-- Slot Menu End-->

<!-- Sport Menu -->
      <div style="margin-top:1px;margin-bottom: 30px; padding:0px; text-align:center" id="sportmenu">
         <div>
            <img class="mySlides-sport" src="https://img.pay4d.info/picrightsport.jpg" width="100%" alt="">
            <img class="mySlides-sport" src="https://img.pay4d.info/picrightsport-b.jpg" width="100%" alt="">
         </div>
         <div class="piclmd-div">
             <div class="abel piclmd-title">SPORT</div>
             <div class="abel piclmd-info">Pertandingan olahraga terlengkap.</div>
         </div>
         <div>
          <img src="images/bgline3.png" width="100%" height="6">
         </div>
       </div>
<!-- Sport Menu End-->

<!-- Tembak Menu -->
      <div style="margin-top:1px;margin-bottom: 30px; padding:0px; text-align:center" id="tembakmenu">
         <div>
            <img class="mySlides-tembak" src="https://img.pay4d.info/picright.jpg" width="100%" alt="">
            <img class="mySlides-tembak" src="https://img.pay4d.info/picright-b.jpg" width="100%" alt="">
         </div>
         <div class="piclmd-div">
             <div class="abel piclmd-title">TEMBAK IKAN</div>
             <div class="abel piclmd-info">Dapatkan jackpot terbesar dari ikan Boss.</div>
         </div>
         <div>
          <img src="images/bgline3.png" width="100%" height="6">
         </div>
       </div>
<!-- Tembak Menu End-->
    
    
   <div style="clear: both;"></div> 

  <div id="mobilelogin" class="panel-danger" style="margin-right:60px;margin-left:60px;margin-top: 30px;">
        <div class="panel-body ptsans" style="padding:0px;">
        <div id="msgbox" style="margin-bottom: 5px;margin-top: 0px"></div>
      <form class="form-group form-group-sm form" style="margin:0px; padding:0px">
                  <div class="input-group" style="margin-bottom: 2px;">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
            		<input type="text" class="form-control ptsans username" name="username" placeholder="Username" value="">
                  </div>
                  <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                      <input type="password" class="form-control password" name="password" placeholder="Password">
                  </div>
                  
        <div class="row verifikasiform">
          <div class="form-group-md col-xs-9 col-sm-11" style="margin-top: 6px;padding-left: 15px;padding-right: 5px;">
              <div class="input-group">
                <span class="input-group-addon"><i class="glyphicon glyphicon-ok-sign"></i></span>
                <input type="text" inputmode="numeric" class="form-control" id="validasi" name="verifikasi" placeholder="Validasi" style="padding: 10px;" autocomplete="off">
              </div>
          </div>
          <div class="form-group-md col-xs-3 col-sm-1" style="margin-top: 5px; padding-right: 15px;padding-left: 0px;">
            <span id="verifikasi"><img src="m/capimg.php?7892" style="height: 50px; width: 100%; border-radius: 5px;margin-top: 2px;"></span>
          </div>     
        </div>
        <input type="hidden" name="verif" class="verifval" value="1">
        
        <input type="submit" value="Masuk" class="btn btn-lg btn-danger btn-block submit" style="margin-top:5px;">
        <input type="hidden" name="task" value="login">
        <input type="hidden" name="loginmobile" value="IylYMP6rvdH+JNCgP5HYCvyLEjmZvrfhpGrkm2K+b/0=">
        <input type="button" value="Daftar Sekarang" class="btn btn-info btn-block" onClick="mregister();" >
      </form>
    </div>
    </div>
    <!-- back -->   
    <div style="margin-top:5px">
    <div id="content" style="padding:10px">
		</div>
    </div>
    

<div style="width: 100%; font-size: 18px; font-weight: bold; margin-top: 20px; margin-bottom: 20px;" class="">
	<div style="margin:0px 20px 30px 20px;" class="text-center">
		<a class="" style="margin: 1px; width: 180px; text-decoration: none; cursor: pointer; color: #d0c074; margin-right: 30px" onclick='$("#contentmobilekontak").slideUp(500);$("#contentmobilepromo").slideToggle(500);'><img src="https://img.pay4d.info/icon-promo.png" style="width:30px; vertical-align:middle; margin-right: 10px; margin-top: -5px;"><i>PROMOSI</i></a>
		<a class="" style="margin: 1px; width: 180px; text-decoration: none; cursor: pointer; color:  #d0c074" onclick='$("#contentmobilepromo").slideUp(500);$("#contentmobilekontak").slideToggle(500);'><img src="https://img.pay4d.info/icon-kontak.png" style="width:30px; vertical-align:middle; margin-right: 10px; margin-top: -5px;"><i>KONTAK KAMI</i></a>
	</div>
</div>
<div style="clear:both;"></div>

<style>
	#contentmobilekontak a
	{
		color: #000;
	}
</style>
<div id="contentmobilekontak" class="abel shadow" style="margin: 20px;border-radius: 10px 10px 10px 10px; display: none;">
	<div style="padding: 20px; background-color: #000; border-radius: 10px 10px 0px 0px; border: solid 2px #CCC;" class="text-center">
   <span style="font-size: 32px;margin-top: 0px;font-weight: bold; color: #FFF">24 JAM NONSTOP</span></br><span class="abel" style="font-size: 25px;color: #d0c074;">MEMBER SERVICE</span>
    </div>

    <div class="abel" style="background-color: #FFF; color: #000; padding: 30px; border-radius: 0px 0px 10px 10px; font-size: 22px">
	        <div style="border-bottom:1px #959595 solid;margin-bottom: 5px;padding: 0px 0px 10px 0px;">
            <img src="https://img.pay4d.info/kontak/wa.png" width="22" style="margin-right: 10px;"><span style="margin-top:7px;">+63 928 902 6606</span>
        </div>
            <div style="border-bottom:1px #959595 solid;margin-bottom: 5px;padding: 0px 0px 10px 0px;">
            <img src="https://img.pay4d.info/kontak/telegram.png" width="22" style="margin-right:10px;"><span style="margin-left: 5px; margin-right: 5px;"></span>@cs_suhu69</span>
        </div>
    	</div>
</div>

<div class="panel panelbg abel" id="contentmobilepromo" style="display: none">
       <div class="panel-body">
                   <div class="shadow" style="width: 100%; margin-top:10px; border:solid 1px #333; border-radius: 10px 10px 10px 10px">
                        <div >
            <img src="images/upload-Promo-20220521225109.jpg" style="width: 100%;border-radius: 10px 10px 0px 0px" alt="SUHU69 | WELCOME BONUS 20%">
            </div>
        	                        <div style="width: 100%; background-color: #000; border-top: 0px; border-radius: 0px 0px 10px 10px; margin-top:0px; padding: 15px">
                <style type="text/css">
    .btn_more {
        width:100%;
        padding: 8px 10px;
        color: rgb(255, 255, 255);
        font-weight: bolder;
        border-radius: 8px;
        background:linear-gradient(0deg, rgb(124, 0, 0) 0%, rgb(196, 0, 0) 100%);
        border: 1px solid rgb(121, 0, 0);
        cursor: pointer;
        text-transform: uppercase;
    }
    .btn_more:focus {
        outline: none;
    }
</style>
<div class="container_promo">
        
    <button class="btn_more" onclick="if (this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display != '') { this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display = ''; this.parentNode.parentNode.getElementsByTagName('div')['hide'].style.display = 'none'; this.innerText = ''; this.value = 'Tutup'; } else { this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display = 'none'; this.parentNode.parentNode.getElementsByTagName('div')['hide'].style.display = ''; this.innerText = ''; this.value = 'Informasi Lengkap'; }">Informasi Lengkap</button>

    <div class="item_show" id="show" style="display: none">
        <center>
            <h2>BONUS DEPOSIT NEW MEMBER 20%</h2>
        </center>

        <p><b>Syarat & Ketentuan Berlaku :</b></p>
  <ol>
    <li><span style="font-size:15px;">Promo hanya bisa di claim 1x (saat pertama melakukan deposit)</span></li>
    <li><span style="font-size:15px;">Minimal deposit untuk mengclaim bonus promo ini adalah IDR 25.000,-</span></li>
    <li><span style="font-size:15px;">Maksimal bonus yang di berikan adalah IDR 5.000,-</span></li>
    <li><span style="font-size:15px;">Syarat withdraw cukup dengan melakukan turnover 1x ( Deposit 25.000 + Bonus 5.000 ) x 1 = 30.000</span></li>
    <li><span style="font-size:15px;">Promo tidak bisa di cancel / di batalkan</span></li>
    <li><span style="font-size:15px;">Segala keputusan SUHU69 bersifat mutlak dan tidak bisa di ganggu gugat</span></li>
    <li><span style="font-size:15px;">Klaim bonus melalui Livechat / Whatsapp / Telegram SUHU69</span></li>
 
  </ol>
        <p><b>Klaim promo disini :</b></p>
  <ol>
    <li><span style="font-size:15px;">Livechat : <a href="https://direct.lc.chat/14152443">Klik disini</a></span></li>
    <li><span style="font-size:15px;">WhatsApp : <a href="https://wa.me/639289026669">(+63) 928 9026 669</a> </span></li>
    <li><span style="font-size:15px;">Telegram : <a href="https://t.me/cs_raja33">@cs_suhu69</a> </span></li>
  </ol>

        </ol>
    </div>
</div>            </div>
                        </div>
                        <div class="shadow" style="width: 100%; margin-top:10px; border:solid 1px #333; border-radius: 10px 10px 10px 10px">
                        <div >
            <img src="images/upload-Promo-20220521225119.jpg" style="width: 100%;border-radius: 10px 10px 0px 0px" alt="SUHU69 | BONUS DEPOSIT HARIAN 5%">
            </div>
        	                        <div style="width: 100%; background-color: #000; border-top: 0px; border-radius: 0px 0px 10px 10px; margin-top:0px; padding: 15px">
                <style type="text/css">
    .btn_more {
        width:100%;
        padding: 8px 10px;
        color: rgb(255, 255, 255);
        font-weight: bolder;
        border-radius: 8px;
        background:linear-gradient(0deg, rgb(124, 0, 0) 0%, rgb(196, 0, 0) 100%);
        border: 1px solid rgb(121, 0, 0);
        cursor: pointer;
        text-transform: uppercase;
    }
    .btn_more:focus {
        outline: none;
    }
</style>
<div class="container_promo">
        
    <button class="btn_more" onclick="if (this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display != '') { this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display = ''; this.parentNode.parentNode.getElementsByTagName('div')['hide'].style.display = 'none'; this.innerText = ''; this.value = 'Tutup'; } else { this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display = 'none'; this.parentNode.parentNode.getElementsByTagName('div')['hide'].style.display = ''; this.innerText = ''; this.value = 'Informasi Lengkap'; }">Informasi Lengkap</button>

    <div class="item_show" id="show" style="display: none">
        <center>
            <h2>BONUS DEPOSIT HARIAN 5%</h2>
        </center>

        <p><b>Syarat & Ketentuan Berlaku :</b></p>
  <ol>
    <li><span style="font-size:15px;">Promo hanya bisa di claim 1x dalam sehari</span></li>
    <li><span style="font-size:15px;">Minimal deposit untuk mengclaim bonus promo ini adalah IDR 25.000,-</span></li>
    <li><span style="font-size:15px;">Maksimal bonus yang di berikan adalah IDR 1.000.000,-</span></li>
    <li><span style="font-size:15px;">Syarat withdraw cukup dengan melakukan turnover 3x ( Deposit 25.000 + Bonus 1.250 ) x 3 = 78.750</span></li>
    <li><span style="font-size:15px;">Promo tidak bisa di cancel / di batalkan</span></li>
    <li><span style="font-size:15px;">Segala keputusan SUHU69 bersifat mutlak dan tidak bisa di ganggu gugat</span></li>
    <li><span style="font-size:15px;">Klaim bonus melalui Livechat / Whatsapp / Telegram SUHU69</span></li>
 
  </ol>
        <p><b>Klaim promo disini :</b></p>
  <ol>
    <li><span style="font-size:15px;">Livechat : <a href="https://direct.lc.chat/14152443">Klik disini</a></span></li>
    <li><span style="font-size:15px;">WhatsApp : <a href="https://wa.me/639289026669">(+63) 928 9026 669</a> </span></li>
    <li><span style="font-size:15px;">Telegram : <a href="https://t.me/cs_raja33">@cs_suhu69</a> </span></li>
  </ol>

        </ol>
    </div>
</div>            </div>
                        </div>
                        <div class="shadow" style="width: 100%; margin-top:10px; border:solid 1px #333; border-radius: 10px 10px 10px 10px">
                        <div >
            <img src="images/upload-Promo-20220521225646.jpg" style="width: 100%;border-radius: 10px 10px 0px 0px" alt="SUHU69 | BONUS CASHBACK ">
            </div>
        	                        <div style="width: 100%; background-color: #000; border-top: 0px; border-radius: 0px 0px 10px 10px; margin-top:0px; padding: 15px">
                <style type="text/css">
    .btn_more {
        width:100%;
        padding: 8px 10px;
        color: rgb(255, 255, 255);
        font-weight: bolder;
        border-radius: 8px;
        background:linear-gradient(0deg, rgb(124, 0, 0) 0%, rgb(196, 0, 0) 100%);
        border: 1px solid rgb(121, 0, 0);
        cursor: pointer;
        text-transform: uppercase;
    }
    .btn_more:focus {
        outline: none;
    }
</style>
<div class="container_promo">
        
    <button class="btn_more" onclick="if (this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display != '') { this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display = ''; this.parentNode.parentNode.getElementsByTagName('div')['hide'].style.display = 'none'; this.innerText = ''; this.value = 'Tutup'; } else { this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display = 'none'; this.parentNode.parentNode.getElementsByTagName('div')['hide'].style.display = ''; this.innerText = ''; this.value = 'Informasi Lengkap'; }">Informasi Lengkap</button>

    <div class="item_show" id="show" style="display: none">
        <center>
            <h2>BONUS TURNOVER 0.25%</h2>
        </center>

        <p><b>Bonus Turnover 0.25% hanya diberikan pada player yang bermain permainan Games Slot, Live Casino, dan Tembak Ikan</b></p>
  <ol>
    <li><span style="font-size:15px;">Bonus Turnover 0.25% akan di bagikan setiap Hari Senin, berlaku untuk semua permainan Kecuali Togel (Periode  Senin s/d Minggu)</span></li>
    <li><span style="font-size:15px;">Bonus Mingguan ini tidak dapat di claim lebih awal</span></li>
    <li><span style="font-size:15px;">Bonus akan langsung di tambahkan kedalam User ID anda</span></li>
    <li><span style="font-size:15px;">Bonus ini tidak dapat digabungkan dengan promosi lainnya</span></li>
    <li><span style="font-size:15px;">Tidak ada Maksimum Cashback & Turnover</span></li>
    <li><span style="font-size:15px;">Bonus hanya di bagikan kepada player yang aktif bermain pada 1 minggu terakhir (Periode  Senin s/d Minggu)</span></li>
    <li><span style="font-size:15px;">Jika ditemukan indikasi kecurangan dalam bentuk apapun, maka bonus akan di batalkan dan mengakibatkan akun Anda di suspend / banned</span></li>
 
  </ol>
        <p><b>NB : Syarat dan Ketentuan bonus berlaku</b></p>

        </ol>
    </div>
</div>            </div>
                        </div>
                        <div class="shadow" style="width: 100%; margin-top:10px; border:solid 1px #333; border-radius: 10px 10px 10px 10px">
                        <div >
            <img src="images/upload-Promo-20220521230435.jpg" style="width: 100%;border-radius: 10px 10px 0px 0px" alt="SUHU69 | DISKON TOGEL">
            </div>
        	                        <div style="width: 100%; background-color: #000; border-top: 0px; border-radius: 0px 0px 10px 10px; margin-top:0px; padding: 15px">
                <style type="text/css">
    .btn_more {
        width:100%;
        padding: 8px 10px;
        color: rgb(255, 255, 255);
        font-weight: bolder;
        border-radius: 8px;
        background:linear-gradient(0deg, rgb(124, 0, 0) 0%, rgb(196, 0, 0) 100%);
        border: 1px solid rgb(121, 0, 0);
        cursor: pointer;
        text-transform: uppercase;
    }
    .btn_more:focus {
        outline: none;
    }
</style>
<div class="container_promo">
        
    <button class="btn_more" onclick="if (this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display != '') { this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display = ''; this.parentNode.parentNode.getElementsByTagName('div')['hide'].style.display = 'none'; this.innerText = ''; this.value = 'Tutup'; } else { this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display = 'none'; this.parentNode.parentNode.getElementsByTagName('div')['hide'].style.display = ''; this.innerText = ''; this.value = 'Informasi Lengkap'; }">Informasi Lengkap</button>

    <div class="item_show" id="show" style="display: none">
        <center>
            <h2>PROMO TOGEL SUHU69</h2>
        </center>

        <p><b>DISKON TOGEL TERBESAR :</b></p>
  <ol>
    <li><span style="font-size:15px;">4D = (Diskon 66%)</span></li>
    <li><span style="font-size:15px;">3D = (Diskon 59%)</span></li>
    <li><span style="font-size:15px;">2D = (Diskon 29%)</span></li>
  </ol>
 <p><b>HADIAH PEMBAYARAN TERBESAR :</b></p>
  <ol>
    <li><span style="font-size:15px;">4D = 3000x</span></li>
    <li><span style="font-size:15px;">3D = 400x</span></li>
    <li><span style="font-size:15px;">2D = 70x</span></li>
  </ol>

        </ol>
    </div>
</div>            </div>
                        </div>
                        <div class="shadow" style="width: 100%; margin-top:10px; border:solid 1px #333; border-radius: 10px 10px 10px 10px">
                        <div >
            <img src="images/upload-Promo-20220521225619.jpg" style="width: 100%;border-radius: 10px 10px 0px 0px" alt="SUHU69 | BONUS REFFERAL 1%">
            </div>
        	                        <div style="width: 100%; background-color: #000; border-top: 0px; border-radius: 0px 0px 10px 10px; margin-top:0px; padding: 15px">
                <style type="text/css">
    .btn_more {
        width:100%;
        padding: 8px 10px;
        color: rgb(255, 255, 255);
        font-weight: bolder;
        border-radius: 8px;
        background:linear-gradient(0deg, rgb(124, 0, 0) 0%, rgb(196, 0, 0) 100%);
        border: 1px solid rgb(121, 0, 0);
        cursor: pointer;
        text-transform: uppercase;
    }
    .btn_more:focus {
        outline: none;
    }
</style>
<div class="container_promo">
        
    <button class="btn_more" onclick="if (this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display != '') { this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display = ''; this.parentNode.parentNode.getElementsByTagName('div')['hide'].style.display = 'none'; this.innerText = ''; this.value = 'Tutup'; } else { this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display = 'none'; this.parentNode.parentNode.getElementsByTagName('div')['hide'].style.display = ''; this.innerText = ''; this.value = 'Informasi Lengkap'; }">Informasi Lengkap</button>

    <div class="item_show" id="show" style="display: none">
        <center>
            <h2>BONUS REFERRAL UP TO 1%</h2>
        </center>
        <p><b>Anda akan mendapatkan Bonus Referal  Setiap Player anda yang melakukan betting. Bonus Referal akan otomatis masuk ke Balance Anda.</b></p>
        <img src="https://i.ibb.co/bFcdQFR/revisi-rate.png" border="0" width="100%" height="100%">
    </div>
</div>            </div>
                        </div>
               </div>
</div>
        
<div class="banner shadow" style="margin:20px 20px 20px 20px; border:solid 2px #FFF; border-radius: 20px; box-shadow:rgba(0,0,0,1) 0px 0px 10px 0px; height: 0; padding-bottom: 33%; position: relative;">
     <img src="images/upload-SlidesMobile-20220521222532.jpg" alt="SUHU69 | BONUS DEPOSIT NEW MEMBER 20%" style="border-radius: 20px; top: 0; left: 0; width: 100%; height: 100%; position: absolute;"/>
</div>
<div class="banner shadow" style="margin:20px 20px 20px 20px; border:solid 2px #FFF; border-radius: 20px; box-shadow:rgba(0,0,0,1) 0px 0px 10px 0px; height: 0; padding-bottom: 33%; position: relative;">
     <img src="https://img.pay4d.info/pop/mobile-opus.jpg" width="100%" alt="" style="border-radius: 20px; top: 0; left: 0; width: 100%; height: 100%; position: absolute;">
</div>

<div style="text-align:center; margin-top:20px; margin-bottom:30px; font-size:20px;">
              <input type="button" class="btn btn-primary abel" style="font-size:20px; font-weight:normal; width:120px" onclick="location.href='/?desktop'" value="Desktop" />
        
        <input type="button" class="btn btn-primary abel" style="font-size:20px; font-weight:normal; width:120px" onclick="location.href='/wap'" value="Wap" />
        <div style="margin-top: 20px;" id="mobileapp">
        </div>
    </div>
  <div style="clear:both;"></div>
<div id="togel" class="shadow">
  <div style="height: 100%; padding:20px 40px 20px 40px;">
  	<table class="table abel" style="width:100%; background:none;">
                <thead>
                	<caption class="datapasaran-title">Last Result Togel</caption>
                	<tr>
              	<th class="datapasaran-title-pasaran">Pasaran</th>
                <th class="datapasaran-title-tanggal tanggal-text">Tanggal</th>
                <th class="datapasaran-title-result result-text">Result</th>
              </tr>
			  </thead>
      </table>
    	<div onclick="$('#togglepasaranHKD').slideToggle(500);">
    <table class="table abel" style="width:100%; background:none;margin-bottom: 0px; font-weight: 400">
        <tr class="borderbottom pointer" style="font-size:20px; border-bottom: none !important; height:20px" >
          <td class="pasaran-text" style="line-height:11px;vertical-align: middle;">
		  HK SIANG          </td>
          <td class="tanggal-text" style="font-size:20px; vertical-align: middle;">05-10-2022</td>
          <td class="result-text"  style="letter-spacing: 1px;vertical-align: middle; text-align:right">8786</td>
        </tr>
    </table>
	</div>
    
    <!-- Toggle Pasaran -->
    <div id="togglepasaranHKD" style="display: none;" onclick="$('#togglepasaranHKD').slideToggle(500);" >
    <table class="table abel pointer" style="width:100%; background:none;  margin:0px;  font-weight: 400">
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">04-10-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">4381</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">03-10-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">9550</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">02-10-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">5717</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">01-10-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">0394</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">30-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">8334</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">29-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">7631</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">28-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">0862</td>
      </tr>
      </table>
</div>
<!-- Toggle Pasaran End-->
    	<div onclick="$('#togglepasaranSYD').slideToggle(500);">
    <table class="table abel" style="width:100%; background:none;margin-bottom: 0px; font-weight: 400">
        <tr class="borderbottom pointer" style="font-size:20px; border-bottom: none !important; height:20px" >
          <td class="pasaran-text" style="line-height:11px;vertical-align: middle;">
		  SYDNEY          </td>
          <td class="tanggal-text" style="font-size:20px; vertical-align: middle;">05-10-2022</td>
          <td class="result-text"  style="letter-spacing: 1px;vertical-align: middle; text-align:right">5841</td>
        </tr>
    </table>
	</div>
    
    <!-- Toggle Pasaran -->
    <div id="togglepasaranSYD" style="display: none;" onclick="$('#togglepasaranSYD').slideToggle(500);" >
    <table class="table abel pointer" style="width:100%; background:none;  margin:0px;  font-weight: 400">
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">04-10-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">8278</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">03-10-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">7884</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">02-10-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">5923</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">01-10-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">6915</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">30-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">3709</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">29-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">9726</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">28-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">7817</td>
      </tr>
      </table>
</div>
<!-- Toggle Pasaran End-->
    	<div onclick="$('#togglepasaranMYD').slideToggle(500);">
    <table class="table abel" style="width:100%; background:none;margin-bottom: 0px; font-weight: 400">
        <tr class="borderbottom pointer" style="font-size:20px; border-bottom: none !important; height:20px" >
          <td class="pasaran-text" style="line-height:11px;vertical-align: middle;">
		  MALAYSIA SIANG          </td>
          <td class="tanggal-text" style="font-size:20px; vertical-align: middle;">05-10-2022</td>
          <td class="result-text"  style="letter-spacing: 1px;vertical-align: middle; text-align:right">3901</td>
        </tr>
    </table>
	</div>
    
    <!-- Toggle Pasaran -->
    <div id="togglepasaranMYD" style="display: none;" onclick="$('#togglepasaranMYD').slideToggle(500);" >
    <table class="table abel pointer" style="width:100%; background:none;  margin:0px;  font-weight: 400">
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">04-10-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">1606</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">03-10-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">6741</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">02-10-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">8007</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">01-10-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">3153</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">30-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">8418</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">29-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">4945</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">28-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">7154</td>
      </tr>
      </table>
</div>
<!-- Toggle Pasaran End-->
    	<div onclick="$('#togglepasaranSG').slideToggle(500);">
    <table class="table abel" style="width:100%; background:none;margin-bottom: 0px; font-weight: 400">
        <tr class="borderbottom pointer" style="font-size:20px; border-bottom: none !important; height:20px" >
          <td class="pasaran-text" style="line-height:11px;vertical-align: middle;">
		  SINGAPORE          </td>
          <td class="tanggal-text" style="font-size:20px; vertical-align: middle;">03-10-2022</td>
          <td class="result-text"  style="letter-spacing: 1px;vertical-align: middle; text-align:right">6284</td>
        </tr>
    </table>
	</div>
    
    <!-- Toggle Pasaran -->
    <div id="togglepasaranSG" style="display: none;" onclick="$('#togglepasaranSG').slideToggle(500);" >
    <table class="table abel pointer" style="width:100%; background:none;  margin:0px;  font-weight: 400">
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">02-10-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">1559</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">01-10-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">1563</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">29-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">0018</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">28-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">5053</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">26-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">3713</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">25-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">0995</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">24-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">0892</td>
      </tr>
      </table>
</div>
<!-- Toggle Pasaran End-->
    	<div onclick="$('#togglepasaranMY').slideToggle(500);">
    <table class="table abel" style="width:100%; background:none;margin-bottom: 0px; font-weight: 400">
        <tr class="borderbottom pointer" style="font-size:20px; border-bottom: none !important; height:20px" >
          <td class="pasaran-text" style="line-height:11px;vertical-align: middle;">
		  MALAYSIA          </td>
          <td class="tanggal-text" style="font-size:20px; vertical-align: middle;">04-10-2022</td>
          <td class="result-text"  style="letter-spacing: 1px;vertical-align: middle; text-align:right">5265</td>
        </tr>
    </table>
	</div>
    
    <!-- Toggle Pasaran -->
    <div id="togglepasaranMY" style="display: none;" onclick="$('#togglepasaranMY').slideToggle(500);" >
    <table class="table abel pointer" style="width:100%; background:none;  margin:0px;  font-weight: 400">
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">03-10-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">0289</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">02-10-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">5085</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">01-10-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">2445</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">30-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">5902</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">29-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">6726</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">28-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">9709</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">27-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">2686</td>
      </tr>
      </table>
</div>
<!-- Toggle Pasaran End-->
    	<div onclick="$('#togglepasaranHK').slideToggle(500);">
    <table class="table abel" style="width:100%; background:none;margin-bottom: 0px; font-weight: 400">
        <tr class="borderbottom pointer" style="font-size:20px; border-bottom: none !important; height:20px" >
          <td class="pasaran-text" style="line-height:11px;vertical-align: middle;">
		  HONGKONG          </td>
          <td class="tanggal-text" style="font-size:20px; vertical-align: middle;">04-10-2022</td>
          <td class="result-text"  style="letter-spacing: 1px;vertical-align: middle; text-align:right">5880</td>
        </tr>
    </table>
	</div>
    
    <!-- Toggle Pasaran -->
    <div id="togglepasaranHK" style="display: none;" onclick="$('#togglepasaranHK').slideToggle(500);" >
    <table class="table abel pointer" style="width:100%; background:none;  margin:0px;  font-weight: 400">
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">03-10-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">2376</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">02-10-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">8317</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">01-10-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">6657</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">30-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">7166</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">29-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">3054</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">28-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">8806</td>
      </tr>
    
      <tr style="height:15px;" >
        <td class="pasaran-text" style="vertical-align: middle; padding-top:0px"></td>
        <td class="tanggal-text" style="font-size:20px; vertical-align: middle; padding-top:0px">27-09-2022</td>
        <td class="result-text"  style="font-size:20px; letter-spacing: 1px;vertical-align: middle; text-align:right; padding-top:0px">5411</td>
      </tr>
      </table>
</div>
<!-- Toggle Pasaran End-->
    	
  </div>
</div>

<div id="keluaran-bottom" style="width:100%; height:3px;"></div>


<div id="footer" class="footer-container abel shadow" style="padding:20px;font-size:14px; text-align:center;">
  </div>
</a>

<div class="copyright-bg abel" style="text-align:center; padding-top:20px; height: 100px; font-size:14px;">
    &copy; 2018 - 2022 Copyright SUHU69.<BR /><a href="?daftar">DAFTAR</a> | <a href="?togel">TOGEL</a>     
    &nbsp;| <a href="?slot">SLOT</a> | <a href="?live">LIVE</a> | <a href="?tembakikan">TEMBAK IKAN</a>
       	&nbsp;| <a href="/?desktop">DESKTOP</a> | <a href="wap">WAP</a><br>
   	<a href="?content=privacypolicy#pp">Kebijakan Privasi</a> | <a href="?content=cookiespolicy#cp">Persetujuan Cookies</a>
</div>
</div>

<div id="desktop" style="font-weight: 400">
<div class="body">
    <!--Container Hover Menu -->
    <div class="boxprod" style="font-family: 'Abel';color: #fff;font-size: 13px;">
    <div class="prodimg" id="prod-togel" style="margin:2px 0px 0px 50px; display:none; text-align:center;">
        <!--
        <span style="display: inline-block;width:100px;margin:0px 5px 0px 5px">
            <a href="?content=register"><img src="images/psr-syd.png" alt=""/></a>
            <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">SYDNEY</span></span>
        -->
        <span style="display: inline-block;width:100px;margin:0px 5px 0px 5px">
            <a href="?content=register"><img src="images/psr-sg.png" alt="" /></a>
            <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">SINGAPORE</span></span>
        <!--
        <span style="display: inline-block;width:100px;margin:0px 5px 0px 5px">
            <a href="?content=register"><img src="images/psr-sg45.png" alt="" /></a>
            <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">SINGAPORE 45</span></span>

        <span style="display: inline-block;width:100px;margin:0px 5px 0px 5px">
            <a href="?content=register"><img src="images/psr-gy.png" alt="" /></a>
            <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">GEYLANG</span></span>

        <span style="display: inline-block;width:100px;margin:0px 5px 0px 5px">
            <a href="?content=register"><img src="images/psr-ml.png" alt=""/></a>
            <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">MALAYSIA</span></span>

        <span style="display: inline-block;width:100px;margin:0px 5px 0px 5px">
         <a href="?content=register"><img src="images/psr-mc.png" alt="" /></a>
         <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">MACAU</span></span>

        <span style="display: inline-block;width:100px;margin:0px 5px 0px 5px">
            <a href="?content=register"><img src="images/psr-qtr.png" alt="" /></a>
            <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">QATAR</span></span>
        -->
        <span style="display: inline-block;width:100px;margin:0px 5px 0px 5px">
            <a href="?content=register"><img src="images/psr-hk.png" alt=""/></a>
            <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">HONGKONG</span></span>
        
    </div>
    <div class="prodimg" id="prod-slot" style="font-family: 'Abel';color: #fff;font-size: 13px; margin:2px 0px 0px 0px; display:none; text-align:center">
        <span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
        <a href="/?content=slot"><img src="https://img.pay4d.info/slot-prag.png" alt="pragmatic play" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">PRAGMATIC PLAY</span>
        </span>
        <span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
        <a href="/?content=slot"><img src="https://img.pay4d.info/slot-pg.png" alt="pg soft" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">PG SOFT</span>
        </span>
	<span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
        <a href="/?content=slot"><img src="https://img.pay4d.info/slot-hab.png" alt="habanero" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">HABANERO</span>
        </span>
	<span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
        <a href="/?content=slot"><img src="https://img.pay4d.info/slot-cq9.png" alt="cq9" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">CQ9</span>
        </span>
	<span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
        <a href="/?content=slot"><img src="https://img.pay4d.info/slot-spad.png" alt="spade gaming" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">SPADE GAMING</span>
        </span>
	<span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
        <a href="/?content=slot"><img src="https://img.pay4d.info/slot-mg.png" alt="mg" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">MICRO GAMING</span>
        </span>
	<span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
        <a href="/?content=slot"><img src="https://img.pay4d.info/slot-jok.png" alt="joker gaming" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">JOKER GAMING</span>
        </span>
	<span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
        <a href="/?content=slot"><img src="https://img.pay4d.info/slot-ttg.png" alt="ttg" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">TOP TREND GAMING</span>
        </span>

  	</div>
<div class="prodimg" id="prod-livegames" style="font-family: 'Abel';color: #fff;font-size: 13px; margin:2px 0px 0px 0px; display:none; text-align:center">
	<span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
        <a href="/?content=livegames"><img src="https://img.pay4d.info/live-pp.png" alt="daftar pragmatic 	play" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">PRAGMATIC PLAY</span>
    	</span>
	<span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
        <a href="/?content=livegames"><img src="https://img.pay4d.info/live-ion.png" alt="daftar ion casino" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">ION CASINO</span>
    	</span>
	<span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
        <a href="/?content=livegames"><img src="https://img.pay4d.info/live-mg.png" alt="daftar microgaming" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">MICRO GAMING</span>
    	</span>
	<span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
        <a href="/?content=livegames"><img src="https://img.pay4d.info/live-opus.png" alt="daftar opusplus" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">OPUS PLUS</span>
    	</span>
	<span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
        <a href="/?content=livegames"><img src="https://img.pay4d.info/live-all.png" alt="daftar allbet" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">ALLBET</span>
    </span>
	<span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
        <a href="/?content=livegames"><img src="https://img.pay4d.info/live-sg.png" alt="daftar sexy gaming" />	</a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">SEXY GAMING</span>
   	 </span>
	
</div>
<div class="prodimg" id="prod-sport" style="font-family: 'Abel';color: #fff;font-size: 13px; margin:2px 0px 0px 0px; display:none; text-align:center">
    <span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
        <a href="/?content=sport"><img src="https://img.pay4d.info/sport-saba.png" alt="daftar sport" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">SABA SPORTS</span>
    </span>
</div>
<div class="prodimg" id="prod-tembak" style="font-family: 'Abel';color: #fff;font-size: 13px; margin:2px 0px 0px 0p; display:none; text-align:center">
        <span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
        <a href="/?content=tembakikan"><img src="https://img.pay4d.info/fish-king.png" alt="daftar tembak ikan" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">FISHING KING</span>
        </span>
        <span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
        <a href="/?content=tembakikan"><img src="https://img.pay4d.info/fish-fortune.png" alt="daftar tembak ikan" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">FORTUNE FISHING</span>
        </span>
	<span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
        <a href="/?content=tembakikan"><img src="https://img.pay4d.info/fish-fishing-god.png" alt="daftar tembak ikan" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">FISHING GOD</span>
        </span>
	<span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
        <a href="/?content=tembakikan"><img src="https://img.pay4d.info/fish-fishing-war.png" alt="daftar tembak ikan" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">FISHING WAR</span>
        </span>
	<span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
	<a href="/?content=tembakikan"><img src="https://img.pay4d.info/fish-alien-hunter.png" alt="daftar tembak ikan" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">ALIEN HUNTER</span>
        </span>
	<span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
	<a href="/?content=tembakikan"><img src="https://img.pay4d.info/fish-zombie.png" alt="daftar tembak ikan" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">ZOMBIE PARTY</span>
	</span>

	<span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
	<a href="/?content=tembakikan"><img src="https://img.pay4d.info/fish-fish-hunter2.png" alt="daftar tembak ikan" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">FISH HUNTER 2</span>
	</span>

	<span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
	<a href="/?content=tembakikan"><img src="https://img.pay4d.info/fish-golden-toad.png" alt="daftar tembak ikan" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">GOLDEN TOAD</span>
	</span>

	<span style="display: inline-block; width:110px;margin:0px 5px 0px 5px">
	<a href="/?content=tembakikan"><img src="https://img.pay4d.info/fish-monster-awaken.png" alt="daftar tembak ikan" /></a>
        <br/><span style="display:block;border:2px #fff solid;border-radius: 5px;">MONSTER AWAKEN</span>
	</span>

        </span>


  </div>
</div>    <!--Container Hover Menu End -->

  <!-- Header Menu -->
<div class="header">
    <div class="logodiv">
        <a href="/"><img src="images/logoweb.png" alt=""/></a>
    </div>
    <div id="desktoplogin" class="ptsans" style="float:right; width:620px; margin-top:10px; text-align:right; font-weight:normal"> 
        <div style="width:620px; padding:6px; border-radius: 5px 0px 0px 5px; float:left">  
        <form class="form-inline form-group-sm form" role="form">
            <span id="msgbox" style="font-size:13px; letter-spacing:1px; padding-top:0px; height:20px; margin-right:10px;"></span>  
            <input type="text" class="form-control username" name="username" placeholder="Nama Akun" value="" style="width:100px;height:30px !important">
            <input type="password" class="form-control password" name="password" style="width:100px; padding-top:5px;height: 30px !important" placeholder="Kata Sandi">
           
           	<span class="verifikasiform">
            <span id="verifikasi"><img src="capimg.php?4398" width="40" height="30" style="border:1px #999 solid;"></span>
            <input type="text" class="form-control" name="verifikasi" id="verform"  style="width:40px;height: 30px !important" autocomplete="off">
            </span>
            <input type="hidden" name="verif" class="verifval" value="1">
            
            <input type="submit" value="Masuk" class="btn btn-danger submit" style="width:90px; margin-top:2px; padding:3px; height: 30px !important">
            <a href="?content=register" class="btn btn-info" style="width:90px; margin-top:2px; padding-top:3px;height:30px;">>> Daftar</a>
            <input type="hidden" name="task" value="login">    
            <input type="hidden" name="logindesktop" value="IylYMP6rvdH+JNCgP5HYCvyLEjmZvrfhpGrkm2K+b/0=">
        </form>
        </div>
    </div>
    		  
                <div class="abel" style="height:30px; padding-top:10px; position:relative; width:635px; text-align:right; float:right; font-size:18px;margin-top: 0px;margin-bottom: 18px;color: #FFF; font-weight: 400;">
              <ul>
            <li><a class="pointer" href="/"><span class="glyphicon glyphicon-home"></span></a></li>
                        <li class="pointer" style="margin-left:18px;"><span class=" prod" prod="prod-togel">TOGEL</span></li>
                          
            <li class="pointer" style="margin-left:18px;"><span class=" prod" prod="prod-slot"><a href="?content=slot" style="text-decoration:none">SLOT</a></span></li>
            <li class="pointer" style="margin-left:18px;"><span class=" prod" prod="prod-livegames"><a href="?content=livegames" style="text-decoration:none">LIVE CASINO</a></span></li>
            <li class="pointer" style="margin-left:18px;"><span class=" prod" prod="prod-sport"><a href="?content=sport" style="text-decoration:none">SPORT</a></span></li>
            <li class="pointer" style="margin-left:18px;"><span class=" prod" prod="prod-tembak"><a href="?content=tembakikan" style="text-decoration:none">TEMBAK IKAN</a></span></li>
                  
            <li style="margin-left:18px;"><a class="pointer" href="?content=promosi" style="text-decoration: none">PROMOSI</a></li>      
            <li style="margin-left:18px;"><a class="pointer" href="?content=bukumimpi" style="text-decoration: none;" data-toggle="tooltip" data-placement="bottom" title="Buku Mimpi"><image src="https://img.pay4d.info/buku-mimpi.png" style="margin-left: 5px;margin-top: -5px;"></a></li>
            <li style="margin-left:12px;" onclick="document.getElementById('modal-wrapper').style.display='block'"><a class="pointer" href="javascript:page('tentang');" style="text-decoration: none;" data-toggle="tooltip" data-placement="bottom" title="Informasi"><image src="https://img.pay4d.info/informasi.png" style="margin-left: 0px;margin-top: -5px;"></a></li>
           <span id="desktopapp"></span>
        </ul> 
    </div>
    <div style="clear:both"></div>    
    </div>
<div style="clear:both"></div>

<!-- tournament -->



<!-- Broadcast -->
	
	<div class="abel broadcast-marquee">
        <div class="header" style="padding:5px; height: 30px;">
             <div style="float:left; width:190px; padding-left:0px;"><span id="timenow" style="font-size: 15px;"></span></div>
             <div style="float:left; width:795px; overflow: hidden" class="marqueedesktop"><div style="white-space:nowrap; font-size: 15px; width: 1200px" id="broadcast"></div></div>
             <div style="clear:both"></div>
			
        </div>
    </div>
	

<!-- Content and Slider -->

	<div>
     <!--Container Slider -->
       <style>
/* YOUR CSS simplified */  
.carousel-inner > .item > img, .carousel-inner > .item > a > img {
        display: block;
        height: 100%;
        width: 100%;
        line-height: 1;
    }

/*Bootstrap Carousel Fade Transition (for Bootstrap 3.3.x)
  CSS from:       http://codepen.io/transportedman/pen/NPWRGq
  and:            http://stackoverflow.com/questions/18548731/bootstrap-3-carousel-fading-to-new-slide-instead-of-sliding-to-new-slide
  Inspired from:  http://codepen.io/Rowno/pen/Afykb*/
.carousel-fade .carousel-inner .item {
  opacity: 0;
  transition-property: opacity;
}    
.carousel-fade .carousel-inner .active {
  opacity: 1;
}    
.carousel-fade .carousel-inner .active.left,
.carousel-fade .carousel-inner .active.right {
  left: 0;
  opacity: 0;
  z-index: 1;
}    
.carousel-fade .carousel-inner .next.left,
.carousel-fade .carousel-inner .prev.right {
  opacity: 1;
}    
.carousel-fade .carousel-control {
  z-index: 2;
}

.carousel-indicators {
  bottom:0px;
}

@media all and (transform-3d), (-webkit-transform-3d) {
    .carousel-fade .carousel-inner > .item.next,
    .carousel-fade .carousel-inner > .item.active.right {
      opacity: 0;
      -webkit-transform: translate3d(0, 0, 0);
              transform: translate3d(0, 0, 0);
    }
    .carousel-fade .carousel-inner > .item.prev,
    .carousel-fade .carousel-inner > .item.active.left {
      opacity: 0;
      -webkit-transform: translate3d(0, 0, 0);
              transform: translate3d(0, 0, 0);
    }
    .carousel-fade .carousel-inner > .item.next.left,
    .carousel-fade .carousel-inner > .item.prev.right,
    .carousel-fade .carousel-inner > .item.active {
      opacity: 1;
      -webkit-transform: translate3d(0, 0, 0);
              transform: translate3d(0, 0, 0);
    }
}
</style>
<div id="myCarousel" class="carousel  slide carousel-fade" data-ride="carousel">
<!-- Wrapper for slides -->
<div class="carousel-inner" style="height: 0; padding-bottom: 20%; position: relative;">
  <div class="item active">
    <img src="images/upload-Slides-20220521222743.jpg" alt="WELCOME TO SUHU69" style="height: 100%; width: 100%">
  </div>
  <div class="item ">
    <img src="images/upload-Slides-20220521222818.jpg" alt="SUHU69 | BONUS DEPOSIT NEW MEMBER 20%" style="height: 100%; width: 100%">
  </div>
  <div class="item ">
    <img src="images/upload-Slides-20220521222907.jpg" alt="SUHU69 | BONUS DEPOSIT HARIAN 5%" style="height: 100%; width: 100%">
  </div>
  <div class="item ">
    <img src="images/upload-Slides-20220521235919.jpg" alt="SUHU69 | BONUS CASHBACK " style="height: 100%; width: 100%">
  </div>
  <div class="item ">
    <img src="images/upload-Slides-20220521223048.jpg" alt="SUHU69 | DEPOSIT VIA PULSA " style="height: 100%; width: 100%">
  </div>
  <div class="item ">
    <img src="images/upload-Slides-20220521223138.jpg" alt="SUHU69 | DISKON TOGEL TERBESAR" style="height: 100%; width: 100%">
  </div>
  <div class="item ">
    <img src="images/upload-Slides-20220521223215.jpg" alt="SUHU69 | BONUS REFFERAL 0.1%" style="height: 100%; width: 100%">
  </div>
  
<div class="item ">
<img src="https://img.pay4d.info/banner/banner-piggypp-okt.jpg" class="sliderwh">
</div>
<div class="item">
<img src="https://img.pay4d.info/banner/hbmg.jpg" class="sliderwh">
</div>
<div class="item">
<img src="https://img.pay4d.info/banner/sg-mar.jpg">
</div>
</div>
<!-- Indicators -->
<ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1" ></li>
    <li data-target="#myCarousel" data-slide-to="2" ></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
    <li data-target="#myCarousel" data-slide-to="4"></li>
    <li data-target="#myCarousel" data-slide-to="5"></li>
    <li data-target="#myCarousel" data-slide-to="6"></li>
    <li data-target="#myCarousel" data-slide-to="7"></li>
    <li data-target="#myCarousel" data-slide-to="8"></li>
    <li data-target="#myCarousel" data-slide-to="9"></li>
  </ol>

</div>    </div>
    
    <div class="header abel" id="boxContent" style="">
     <!--Container Content --> 
         <div id="content" style="padding-top:0px;margin-left: 0px; margin-right:0px;">
                                                         </div>
         
                  	<style>
			body {
			  background-color:#340606;
			  }
		   </style>
                  
         <div style="clear:both;"></div>

     </div>
     
<!-- Pasaran -->

    <div>
     <div style="text-align:center"><img src="images/bgline.png"></div>
          <div class="bgdatapasaran" style="height:120px">
         <div id="dataPasaran" style="margin-top:0px; text-align:center">
                <a href="?content=hasil&pid=HKD">
       
       <div style="width:96px; display:inline-block; margin-left:0px; margin-right:-1px; opacity:1.0; text-align:center; font-weight: 400">
       		          <div class="abel" id="datapasaran-divname">
          		<span class="abel">HK SIANG</span>
            </div>
            <div id="datapasaran-divnomor">
              <div class="oswald" id="datapasaran-divnomor-text">
                8786                </div>
            </div>
            <div class="abel" id="datapasaran-date">RABU 5/10/2022            </div>
            
        </div>
        </a>
        
              <a href="?content=hasil&pid=SYD">
       
       <div style="width:96px; display:inline-block; margin-left:0px; margin-right:-1px; opacity:1.0; text-align:center; font-weight: 400">
       		          <div class="abel" id="datapasaran-divname">
          		<span class="abel">SYDNEY</span>
            </div>
            <div id="datapasaran-divnomor">
              <div class="oswald" id="datapasaran-divnomor-text">
                5841                </div>
            </div>
            <div class="abel" id="datapasaran-date">RABU 5/10/2022            </div>
            
        </div>
        </a>
        
              <a href="?content=hasil&pid=MYD">
       
       <div style="width:96px; display:inline-block; margin-left:0px; margin-right:-1px; opacity:1.0; text-align:center; font-weight: 400">
       		          <div class="abel" id="datapasaran-divname">
          		<span class="abel">MALAYSIA SIANG</span>
            </div>
            <div id="datapasaran-divnomor">
              <div class="oswald" id="datapasaran-divnomor-text">
                3901                </div>
            </div>
            <div class="abel" id="datapasaran-date">RABU 5/10/2022            </div>
            
        </div>
        </a>
        
              <a href="?content=hasil&pid=SG">
       
       <div style="width:96px; display:inline-block; margin-left:0px; margin-right:-1px; opacity:1.0; text-align:center; font-weight: 400">
       		          <div class="abel" id="datapasaran-divname">
          		<span class="abel">SINGAPORE</span>
            </div>
            <div id="datapasaran-divnomor">
              <div class="oswald" id="datapasaran-divnomor-text">
                6284                </div>
            </div>
            <div class="abel" id="datapasaran-date">SENIN 3/10/2022            </div>
            
        </div>
        </a>
        
              <a href="?content=hasil&pid=MY">
       
       <div style="width:96px; display:inline-block; margin-left:0px; margin-right:-1px; opacity:1.0; text-align:center; font-weight: 400">
       		          <div class="abel" id="datapasaran-divname">
          		<span class="abel">MALAYSIA</span>
            </div>
            <div id="datapasaran-divnomor">
              <div class="oswald" id="datapasaran-divnomor-text">
                5265                </div>
            </div>
            <div class="abel" id="datapasaran-date">SELASA 4/10/2022            </div>
            
        </div>
        </a>
        
              <a href="?content=hasil&pid=HK">
       
       <div style="width:96px; display:inline-block; margin-left:0px; margin-right:-1px; opacity:1.0; text-align:center; font-weight: 400">
       		          <div class="abel" id="datapasaran-divname">
          		<span class="abel">HONGKONG</span>
            </div>
            <div id="datapasaran-divnomor">
              <div class="oswald" id="datapasaran-divnomor-text">
                5880                </div>
            </div>
            <div class="abel" id="datapasaran-date">SELASA 4/10/2022            </div>
            
        </div>
        </a>
        
           	<div style="clear:both"></div>         </div>
     </div>
 	    </div>
    <div style="clear:both;"></div>

<!-- Pasaran End -->

<div class="header" style="margin-top:4px">
    	<div class="oswald togelonline-div"><span>TOGEL ONLINE</span><span class="abel togelonline-div-info">Diskon dan Kemenangan terbaik</span></div>
         <div><img src="images/bgline2.png" width="100%"></div>
</div>

<!-- 3 picture at bottom -->
  
<div class="header" style="margin-top:4px">
   <div class="row" style="margin:0px; padding:0px">
     <div class="col-xs-4" style="margin:0px; padding:0px; width:331px; margin-right:1px;">
         <div id="picmid" class="piclmd-img"></div>
         <div class="oswald piclmd-div">
             <div class="piclmd-title">SLOT &amp; TEMBAK IKAN</div>
             <div class="abel piclmd-info">Ratusan jenis permainan menarik.</div>
         </div>
         <div>
            <img src="images/bgline3.png" width="100%" height="6">
         </div>
    </div>
    <div class="col-xs-4" style="margin:0px;padding:0px; width:331px; margin-right:2px; margin-left:2px">
        <div id="picleft" class="piclmd-img"></div>
         <div class="oswald piclmd-div">
             <div class="piclmd-title">LIVE CASINO</div>
             <div class="abel piclmd-info">Permainan-permainan menarik secara Live.</div>
         </div>
         <div>
            <img src="images/bgline3.png" width="100%" height="6">
         </div>
     </div>
     <div class="col-xs-4" style="margin:0px; padding:0px; width:331px; margin-left:1px">
        <div id="picright" class="piclmd-img"></div>
         <div class="oswald piclmd-div">
             <div class="piclmd-title">SPORT</div>
             <div class="abel piclmd-info">Pertandingan olahraga terlengkap.</div>
         </div>
         <div>
            <img src="images/bgline3.png" width="100%" height="6">
         </div>
     </div>
     
     </div>
 </div>
 

<!-- Provider and Akses-->

  
<div class="header" style="font-size:12px; letter-spacing:1px; margin-top:5px;">    
    <div style="height:125px; margin-top:0px;">
        <img src="https://img.pay4d.info/logo_providernewn.png" />
 
    </div>
    <div style="clear:both"></div>
</div>
<!-- Provider and Akses End-->


<!-- Metode Pembayaran Bank-->


<!-- Metode Pembayaran Bank End-->

     
<div class="footer-container shadow" id="footer">
     <div class="header abel">
        <div id="footercontainer" class="text-default" style="margin:15px; text-align:center;">        <div id="footercontainer" class="text-default" style="margin:15px; text-align:center;">
<h1><strong>SUHU69 : Agen Betting Online Terbesar Terpercaya - Menang Berapapun Pasti DIBAYAR ! </strong></h1>
<p style="text-align:justify;">SUHU69 : Pusat Ling Judi Bocoran Bo Slotgames Togel Gacor 100% Hoki Jp Pasti Bayar . Provider Slot Pay4d Terbesar Di Indonesia Seperti Pragmatic, Habanero, Spadegaming , Ion Casino, Cq9 , Joker 123 338, PGsoft, Sexy Gaming slot, Idn Live , Sbobet Resmi , cmd368, Saba sport dan lainnya . Selain Itu Suhuslot Ini Memiliki Permainan slot online , live kasino, judi bola, tembak ikan , togel darat offline online dan lainnya. SUHU69 Menerima Deposit Pakai Pulsa telkomsel , xl , ovo , dana, gopay, emoney, ewalet dan lainnya yang online 24jam dengan rate terbaik. Tentunya Bermain disini adalah pilihan tepat karena situs ini berlisensi resmi pagcor dan juga bermain disini pasti gacor yang artinya anda bisa dapat profit banyak dibanding main disitus lain yang belum jelas dibayar dan belum jelas gacor.  Buat anda pencinta togel online atau yang  biasa disebut bettor mania yang suka bermain colok jitu, naga, kombinasi, 2D 3D 4D anda bisa bermain disini cukup 1 user id saja. Dengan Modal Yang Minimal Kecil anda bisa bermain dan betaruh disitus judi online terbaik di indonesia.</p>

<h3><strong>SUHU69 : Bandar Judi Bo Toto Togel Online Modal Receh Bet 100 Perak Auto Tembus 2D 3D 4D | Angka Kramat Jitu Result Terupdate 100% AMAN </strong></h3>
<p style="text-align:justify;"> Buat Anda Pecinta Togel mania dimanapun anda berada . Bermain di SUHU69 yang dikenal sebagai Bandar Judi Bo Toto Togel Online Modal Receh Bet 100 Perak Auto TEmbus 2D 3D 4D | Angka Kramat Jitu Result Terupdate 100% AMAN. Anda Bisa Memilih Berbagai Pasaran ternama terbesar di asia seperti Hongkong sydney singapore  macau jepang wuhan dan lainnya disini. Bosan Menunggu result hari ini keluar? Anda bisa menikmati permainan lain seperti slott game yang jamin skater sensational gacor setiap hari. Bonus Maxwin Jekpot Berapapun Pasti Dibayar pihak SUHU69 . Tunggu apa lagi? Cari apa lagi? Situs Terbaik dan sudah pasti aman didepan mata , Join Now & Claim Bonus Bonusnya Tanpa ribet  </p>

<h4><strong>SUHU69 : Situs Judi Tembak Ikan Mobile  Dan Taruhan Judi Deposit Uang Asli Pakai Ewalet Emoney Pasti Hoki</strong></h4>
<p style="text-align:justify;"> SUHU69 : Situs Judi Tembak Ikan Mobile  Dan Taruhan Judi Deposit Uang Asli Pakai Ewalet Emoney Pasti Hoki . Bukan Hanya Bermain Tembak Ikan Tetapi Banyak Games Lainnya Yang bisa anda akses di SUHU69 . Rekomendasi banyak pemain judi dari seluruh indonesia mereka menyebut SUHU69 adalah situs raja dewa king dari segala permainan karena disini mereka merasa nyaman dan diperlakukan sangat profresional oleh cs kami yang 24jam online . Mulai Dari proses Depo Wd yang sangat cepat , Keluhan Member Yang langsung ditanganin & Kami memberi garansi kepada member JP BERAPAPUN PASTI DI BAYAR Tanpa ribet . Real Player Vs Player Tanpa ada cheat ataupun kecurangan sistem jika anda bermain disini. </p></div>

<h4><strong>Link Alternatif Live Kasino Bacarat Rolet Sicbo Blackjack Dragon Tiger Bull Bull Suwit Angka Gacor & Pasti Bayar</strong></h4>
<p style="text-align:justify;"> SUHU69 : Menyediakan Banyak Permainan kasino yang menarik dan populer di asia. Lebih dari 1000 Table meja siap dimainkan di layani oleh dealer profesional kami yang live dan anda bisa menyaksikan pasangan taruhan anda secara langsung . Anda Dapat Bermain Kasino Seperti Bakarat Bacarat Rolet Sicbo Blackjack Dragon Tiger Bull Bull Suwit Angka Niu Niu Monopoly Red White Oglok Dice 6 Head Tail Billiard 48D 24D 12D Dan Masih Banyak Sekali Permainan Live Kasino Yang bisa anda temui di SUHU69 . Semua permainan memiliki rate persentasi rtp maxwin yang tingggi , tidak ada settingan tidak ada kecurangan semua murni pemain vs pemain dan live secara langsung. Rasakan Sensasi Adrenalin Bermain disini Menang jp 1M sekalipun tetap di bayar tanpa ribet . Games Tranding Di asia Semua ada disini Dengan Deposit Receh Anda Bisa Bertaruh Secara Aman Melalui Mobile / laptop anda dimanapun dan kapanpun </p></div>

    </div>
</div></div>
    </div>
</div>

<!-- footer End -->

<!-- footer copyright -->
<div class="footer-copyright-bg">
    <div class="header">
        <div class="abel footer-copyright">
            <div class="footer-copyright-div"><img src="https://img.pay4d.info/footern.png" width="1000" alt=""/></div>
            <span style="float:left"><a href="?content=privacypolicy" style="color:#FFF">Kebijakan Privasi</a> | <a href="?content=cookiespolicy" style="color:#FFF">Persetujuan Cookies</a></span>
        	<span style="float:right">&copy; 2018 - 2022 Copyright SUHU69. All Rights Reserved. 
        <a href="/?mobile" class="btn abel wapmobile" style="margin-left:25px;">MOBILE</a> 
        <a href="wap" class="btn abel wapmobile">WAP</a> 
    </span>
    	<div style="clear:both"></div>
        </div>
    </div>
</div>

<!-- footer copyright End-->


<!--Informasi Modal -->
<div id="modal-wrapper" class="modal" style=" background:none;">

    <div class="slideDown" id="informasi-menu">
      <div class="row">
        <div class="col-xs-3" style="padding-right:0px; width:150px">
            <img src="images/logoweb.png" id="informasi-logo" width="120"/>
            <div class="menuleft abel" style="margin-top:28px;">
                <ul>
                    <li class="active"><a href="javascript:page('tentang');" class="btn btn-black">TENTANG</a></li>
                    <li><a href="javascript:page('bantuan');" class="btn btn-black">BANTUAN</a></li>
                    <li><a href="javascript:page('peraturan');" class="btn btn-black">PERATURAN</a></li>
                    <li><a href="javascript:page('bank');" class="btn btn-black">BANK</a></li>
                    <li><a href="javascript:page('hubungi');" class="btn btn-black">HUBUNGI KAMI</a></li>

                </ul>
            </div>
       </div>    
       <div class="col-xs-9" id="informasi-content">
            <div onclick="document.getElementById('modal-wrapper').style.display='none'" class="closebox" title="Close Informasi">&times;</div>
            <div style="margin-top:35px; margin-left:0px; height:600px; overflow: auto; z-index:1;" id="content2"> 
            </div>
        </div>
        
    </div>
  </div>
</div>

<!-- Image Cache -->

<div id="imagecache" style="display:none">
    <img src="https://img.pay4d.info/picleft-b.jpg" alt=""/>
    <img src="https://img.pay4d.info/picmid-b.jpg" alt=""/>
    <img src="https://img.pay4d.info/picright-b.jpg" alt=""/>
    <img src="images/bg.jpg" alt=""/>
</div>

<!-- Kontak Kami sidenav-->
        
<div id="mySidenav" class="sidenav">
    <div id="nav">
        <img id="about" src="images/kontak.png">
        <div class="ptsans" style="width:200px; position:absolute;margin-left:60px;margin-top: -287px;font-size: 13px;">
           <div id="kontak-title">
           <span style="font-size: 18px;margin-top: 0px;font-weight: bold">24 JAM NONSTOP</span></br><span class="abel" style="font-size: 15px;">MEMBER SERVICE</span>
            </div>
        
            <div class="abel" id="kontak-content">
            
			
			                <div style="border-bottom:1px #959595 solid;margin-bottom: 5px;padding: 0px 0px 5px 0px;">
                    <img src="https://img.pay4d.info/kontak/wa.png" width="22"/ style="margin-right: 5px;"><span style="margin-top:7px;">+63 928 902 6606</span>
                </div>
                            <div style="border-bottom:1px #959595 solid;margin-bottom: 5px;padding: 0px 0px 5px 0px;">
                    <img src="https://img.pay4d.info/kontak/telegram.png" width="22"/><span style="margin-top:7px;"><span style="margin-left: 5px; margin-right: 5px;"></span>@cs_suhu69</span>
                </div>
                        
                
                <div>
                    <input type="button" value="DAFTAR SEKARANG" class="btn btn-info" style="width:172px; margin-top:2px;height:42px;padding: 2px;border-radius: 5px;border:1px #66c4ef solid;font-size: 15px;" onClick="register();" >
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<!-- JS -->
	<script> var mobileurl = 'm/';</script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
    <script src="js/webduo35.js"></script>
    
            <script>
    $('.verifikasiform').hide();
	$('.verifval').val('0');
    </script>
        	<script src="js/jquery.marquee.min.js"></script>
	<script src="js/jquery.pause.min.js"></script>
	<script>
    $('.marqueedesktop').marquee({
		speed: 75,
		gap: 50,
		delayBeforeStart: 0,
		direction: 'left',
		duplicated: true,
		pauseOnHover: true
	});
	$('.marqueemobile').marquee({
		speed: 75,
		gap: 50,
		delayBeforeStart: 0,
		direction: 'left',
		duplicated: true,
		pauseOnHover: true
	});
    </script>

<!--WEBBANER -->
<div></div>
<!--POP UP -->
  <div class="modal fade" id="promo">
    <div class="modal-dialog" style="margin:180px auto 0px; width:600px; padding:0px">
      <div class="modal-content" style="padding:0px; border-radius:0px;">
        <div class="modal-body" style="padding:0px;">
            <img src="images/upload-Popup-20220521223302.jpg" alt="POP UP SUHU69" style="border:2px solid #FFF; width: 600px; height: 300px;"/>
            <button type="btn button" class="closepop" data-dismiss="modal" style="color:#FFF; margin-top:10px">&times;</button>
        </div>
      </div>
    </div>
  </div> 

<!-- LIVE CHAT -->
<!-- Start of LiveChat (www.livechat.com) code -->
<script>
    window.__lc = window.__lc || {};
    window.__lc.license = 14152443;
    ;(function(n,t,c){function i(n){return e._h?e._h.apply(null,n):e._q.push(n)}var e={_q:[],_h:null,_v:"2.0",on:function(){i(["on",c.call(arguments)])},once:function(){i(["once",c.call(arguments)])},off:function(){i(["off",c.call(arguments)])},get:function(){if(!e._h)throw new Error("[LiveChatWidget] You can't use getters before load.");return i(["get",c.call(arguments)])},call:function(){i(["call",c.call(arguments)])},init:function(){var n=t.createElement("script");n.async=!0,n.type="text/javascript",n.src="https://cdn.livechatinc.com/tracking.js",t.head.appendChild(n)}};!n.__lc.asyncInit&&e.init(),n.LiveChatWidget=n.LiveChatWidget||e}(window,document,[].slice))
</script>
<noscript><a href="https://www.livechat.com/chat-with/14152443/" rel="nofollow">Chat with us</a>, powered by <a href="https://www.livechat.com/?welcome" rel="noopener nofollow" target="_blank">LiveChat</a></noscript>
<!-- End of LiveChat code -->
<!-- GetButton.io widget -->
<script type="text/javascript">
    (function () {
        var options = {
            whatsapp: "+639289026606", // WhatsApp number
            telegram: "cs_suhu69", // Telegram bot username
            call_to_action: "Message us", // Call to action
            button_color: "#E74339", // Color of button
            position: "left", // Position may be 'right' or 'left'
            order: "whatsapp,telegram", // Order of buttons
        };
        var proto = document.location.protocol, host = "getbutton.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<!-- /GetButton.io widget -->
<script>
var modal = document.getElementById('modal-wrapper');
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
</div>

<!-- POP UP COOKIES -->
<div id="boxprivacy" style="position: fixed;left: 0;bottom: 0;width: 100%; background-color: #000; box-shadow:rgba(0,0,0,1) 0px 0px 10px 0px; opacity: 0.85; z-index: 2147483640; color: #d0c074">
  <div style="margin:0px; padding: 15px; padding-right: 60px; border: 1px solid #999;">
        <div>
    </a>Kami menggunakan cookies untuk mengoptimalkan navigasi, fitur serta konten yang lebih Relevan. Untuk detail informasi lengkap tentang cookies silahkan lihat <a href='?content=cookiespolicy#cp'>Kebijakan Cookies</a> kami. Dengan menggunakan situs ini, Anda menyetujui penggunaan cookies serta data pribadi kami sesuai dengan <a href='?content=privacypolicy#pp'>Kebijakan Privasi</a> kami.    </div>  
  </div>
  <div>
     <div onclick="document.getElementById('boxprivacy').style.display='none'" class="closebox" title="Close Box" style="margin-right: 10px;">&times;</div>
  </div>
</div>
<script>
    $( "#boxprivacy" ).blur(function() {
    alert( "Handler for .blur() called." );
});
</script>   

</body>
</html>
